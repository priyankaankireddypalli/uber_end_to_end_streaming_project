# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # STREAM RIDES Transformation

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE dlt_learn.bronze.stg_rides

# COMMAND ----------

df = spark.read.table('dlt_learn.bronze.rides_rawdata')
display(df)

# COMMAND ----------

df_bulk = spark.sql("SELECT * FROM dlt_learn.bronze.bulk_rides")
df_bulk.schema

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
rides_schema = StructType([StructField('ride_id', StringType(), True), StructField('confirmation_number', StringType(), True), StructField('passenger_id', StringType(), True), StructField('driver_id', StringType(), True), StructField('vehicle_id', StringType(), True), StructField('pickup_location_id', StringType(), True), StructField('dropoff_location_id', StringType(), True), StructField('vehicle_type_id', LongType(), True), StructField('vehicle_make_id', LongType(), True), StructField('payment_method_id', LongType(), True), StructField('ride_status_id', LongType(), True), StructField('pickup_city_id', LongType(), True), StructField('dropoff_city_id', LongType(), True), StructField('cancellation_reason_id', LongType(), True), StructField('passenger_name', StringType(), True), StructField('passenger_email', StringType(), True), StructField('passenger_phone', StringType(), True), StructField('driver_name', StringType(), True), StructField('driver_rating', DoubleType(), True), StructField('driver_phone', StringType(), True), StructField('driver_license', StringType(), True), StructField('vehicle_model', StringType(), True), StructField('vehicle_color', StringType(), True), StructField('license_plate', StringType(), True), StructField('pickup_address', StringType(), True), StructField('pickup_latitude', DoubleType(), True), StructField('pickup_longitude', DoubleType(), True), StructField('dropoff_address', StringType(), True), StructField('dropoff_latitude', DoubleType(), True), StructField('dropoff_longitude', DoubleType(), True), StructField('distance_miles', DoubleType(), True), StructField('duration_minutes', LongType(), True), StructField('booking_timestamp', TimestampType(), True), StructField('pickup_timestamp', StringType(), True), StructField('dropoff_timestamp', StringType(), True), StructField('base_fare', DoubleType(), True), StructField('distance_fare', DoubleType(), True), StructField('time_fare', DoubleType(), True), StructField('surge_multiplier', DoubleType(), True), StructField('subtotal', DoubleType(), True), StructField('tip_amount', LongType(), True), StructField('total_fare', DoubleType(), True), StructField('rating', StringType(), True)])

# COMMAND ----------

from pyspark.sql import functions as F
df_parsed = df.withColumn("parsed_rides", F.from_json(F.col("rides"), rides_schema))\
    .select("parsed_rides.*")
display(df_parsed)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dlt_learn.bronze.stg_rides

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # JINJA TEMPLATE FOR OBT

# COMMAND ----------

pip install jinja2

# COMMAND ----------

jinja_config = [
    {
        "table_name":"dlt_learn.bronze.stg_rides stg_rides",
        "select":"stg_rides.*",
        "where":"",
    },
    {
        "table_name":"dlt_learn.bronze.map_vehicle_types map_vehicle_types",
        "select":"map_vehicle_types.vehicle_type,map_vehicle_types.description,map_vehicle_types.base_rate,map_vehicle_types.per_mile,map_vehicle_types.per_minute",
        "where":"",
        "condition":"stg_rides.vehicle_type_id = map_vehicle_types.vehicle_type_id"
    },
     {
        "table_name":"dlt_learn.bronze.map_vehicle_makes map_vehicle_makes",
        "select":"map_vehicle_makes.vehicle_make",
        "where":"",
        "condition":"stg_rides.vehicle_make_id = map_vehicle_makes.vehicle_make_id"
    },
     {
        "table_name":"dlt_learn.bronze.map_cancellation_reasons map_cancellation_reasons",
        "select":"map_cancellation_reasons.cancellation_reason",
        "where":"",
        "condition":"stg_rides.cancellation_reason_id = map_cancellation_reasons.cancellation_reason_id"
    },
     {
        "table_name":"dlt_learn.bronze.map_payment_methods map_payment_methods",
        "select":"map_payment_methods.payment_method,map_payment_methods.is_card,map_payment_methods.requires_auth",
        "where":"",
        "condition":"stg_rides.payment_method_id = map_payment_methods.payment_method_id"
    },
     {
        "table_name":"dlt_learn.bronze.map_ride_statuses map_ride_statuses",
        "select":"map_ride_statuses.ride_status",
        "where":"",
        "condition":"stg_rides.ride_status_id = map_ride_statuses.ride_status_id"
    # },
    #  {
    #     "table_name":"dlt_learn.bronze.map_pickup_cities map_pickup_cities",
    #     "select":"map_pickup_cities.city,map_pickup_cities.state,map_pickup_cities.region",
    #     "where":"",
    #     "condition":"stg_rides.pickup_city_id = map_pickup_cities.city_id"
    # },
    #  {
    #     "table_name":"dlt_learn.bronze.map_dropoff_cities map_dropoff_cities",
    #     "select":"map_dropoff_cities.city",
    #     "where":"",
    #     "condition":"stg_rides.dropoff_city_id = map_dropoff_cities.city_id"
    # }]

# COMMAND ----------

from jinja2 import Template

# COMMAND ----------

# Undersatand jinga concepts like for loop, if condition and variables
for config in jinja_config:
    print(config)
    print(config['table_name'])
    print(config['select'])
    print(config['where'])
    print(config['condition'])

# for loops {% for i in iterable%}
# if condition {% if %}
# variable {{ }}


# COMMAND ----------

jinja_str = """
SELECT
    {% for config in jinja_config %}
        {{ config['select'] }}
        {% if not loop.last %}
            ,
            {% endif %}
    {% endfor %}
FROM 
     {% for config in jinja_config %}
        {% if loop.first %}
            {{ config['table_name']}}
        {% else %}
            LEFT JOIN {{ config['table_name']}} ON {{ config['condition']}}
        {% endif %}
    {% endfor %}  

    {% for config in jinja_config %}
        {% if loop.first %}
            {% if config.where != ''%}
                WHERE
            {% endif %}
        {% endif %}
        {% if not loop.last %}
            {% if config.where != ''%}            
            AND
            {% endif %}
        {% endif %}
    {% endfor %}
"""




# COMMAND ----------

template = Template(jinja_str)
rendered = template.render(jinja_config=jinja_config)
print(rendered)


# COMMAND ----------

display(spark.sql(rendered))


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC     stg_rides.*
# MAGIC FROM 
# MAGIC     dlt_learn.bronze.stg_rides
# MAGIC LEFT JOIN 
# MAGIC     dlt_learn.bronze.map_vehicle_types
# MAGIC ON
# MAGIC     stg_rides.vehicle_type_id = map_vehicle_types.vehicle_type_id
# MAGIC LEFT JOIN
# MAGIC     dlt_learn.bronze.map_vehicle_makes
# MAGIC ON 
# MAGIC     stg_rides.vehicle_make_id = map_vehicle_makes.vehicle_make_id
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select current_timestamp;

# COMMAND ----------

# MAGIC %sql
# MAGIC select  from dlt_learn.bronze.silver_obt;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     distance_miles,
# MAGIC     duration_minutes,
# MAGIC     base_fare,
# MAGIC     distance_fare,
# MAGIC     time_fare,
# MAGIC     surge_multiplier,
# MAGIC     subtotal,
# MAGIC     tip_amount,
# MAGIC     total_fare,
# MAGIC     rating,
# MAGIC     base_rate,
# MAGIC     per_mile,
# MAGIC     per_minute
# MAGIC FROM 
# MAGIC     dlt_learn.bronze.silver_obt

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     distinct(passenger_id) as passenger_id,
# MAGIC     , 
# MAGIC     passenger_email,
# MAGIC     passenger_phone
# MAGIC FROM dlt_learn.bronze.silver_obt

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dlt_learn.bronze.dim_passenger;

# COMMAND ----------

