# Databricks notebook source
spark.read.table("bronze.bronze_table")

# COMMAND ----------

# import pandas as pd

# df = pd.read_parquet("https://dltexternaldatalake.blob.core.windows.net/raw/ingestion/map_cities.json.parquet?sp=r&st=2026-09-04T09:33:16Z&se=2026-09-05T17:48:16Z&spr=https&sv=2026-02-06&sr=c&sig=%2BtPwUGdg3GNS1Ex945kQXKEvy6lM6WRoBznL3c0ziNU%3D")

# df_spark = spark.createDataFrame(df)
# display(df_spark)

# COMMAND ----------

files = [
{"file":"bulk_rides.json"},
{"file":"map_cancellation_reasons.json"},
{"file":"map_cities.json"},
{"file":"map_payment_methods.json"},
{"file":"map_ride_statuses.json"},
{"file":"map_vehicle_makes.json"},
{"file":"map_vehicle_types.json"}
]
for file in files:
    i = file["file"]
    print(i[:-5])

# COMMAND ----------

# read data from adls gen 2 to bronze

import pandas as pd

for file in files:
    i = file["file"]
    url = f"https://dltexternaldatalake.blob.core.windows.net/raw/ingestion/{i}.parquet?sp=r&st=2026-09-04T09:33:16Z&se=2026-09-05T17:48:16Z&spr=https&sv=2026-02-06&sr=c&sig=%2BtPwUGdg3GNS1Ex945kQXKEvy6lM6WRoBznL3c0ziNU%3D"

    df = pd.read_parquet(url)
    df_spark = spark.createDataFrame(df)
    # display(df_spark)

    # write to adls gen2 bronze 
    df_spark.write.mode("overwrite")\
        .option("overwriteSchema", "true")\
        .saveAsTable(f"bronze.{i[:-5]}")

    

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dlt_learn.bronze.map_cities;

# COMMAND ----------

