from pyspark import pipelines as dp

dp.create_streaming_table("dim_passenger")

@dp.view
def dim_passenger_view():
    df = spark.readStream.table("silver_obt")
    df = df.select("passenger_id", "passenger_name", "passenger_email", "passenger_phone")
    df = df.dropDuplicates(subset=['passenger_id'])
    return df

# dim passenger
dp.create_auto_cdc_flow(
    target = 'dim_passenger',
    source = 'dim_passenger_view',
    keys = ["passenger_id"],
    sequence_by = "passenger_id",
    stored_as_scd_type = 1
)

# create an empty streaming table
dp.create_streaming_table("dim_driver")

@dp.view
def dim_driver_view():
    df = spark.readStream.table("silver_obt")
    df = df.select('driver_id','driver_name','driver_rating','driver_phone','driver_license')
    df = df.dropDuplicates(subset = ['driver_id'])
    return df

# dim driver
dp.create_auto_cdc_flow(
    target = 'dim_driver',
    source = 'dim_driver_view',
    keys = ["driver_id"],
    sequence_by = "driver_id",
    stored_as_scd_type = 1
)


# create an empty streaming table
dp.create_streaming_table("dim_vehicle")

@dp.view
def dim_vehicle_view():
    df = spark.readStream.table("silver_obt")
    df = df.select('vehicle_id','vehicle_make_id','vehicle_model','vehicle_color','license_plate','vehicle_make','vehicle_type')
    df = df.dropDuplicates(subset = ['vehicle_id'])
    return df

# dim vehicle
dp.create_auto_cdc_flow(
    target = 'dim_vehicle',
    source = 'dim_vehicle_view',
    keys = ["vehicle_id"],
    sequence_by = "vehicle_id",
    stored_as_scd_type = 1
)

# create an empty streaming table
dp.create_streaming_table("dim_payment")

@dp.view
def dim_payment_view():
    df = spark.readStream.table("silver_obt")
    df = df.select('payment_method_id','payment_method','is_card','requires_auth')
    df = df.dropDuplicates(subset = ['payment_method_id'])
    return df

# dim payment
dp.create_auto_cdc_flow(
    target = 'dim_payment',
    source = 'dim_payment_view',
    keys = ["payment_method_id"],
    sequence_by = "payment_method_id",
    stored_as_scd_type = 1
)

# create an empty streaming table
dp.create_streaming_table("dim_booking")

@dp.view
def dim_booking_view():
    df = spark.readStream.table("silver_obt")
    df = df.select('ride_id','confirmation_number','dropoff_location_id','ride_status_id','dropoff_city_id','cancellation_reason_id','dropoff_address','dropoff_latitude','dropoff_longitude','booking_timestamp','dropoff_timestamp')
    df = df.dropDuplicates(subset = ['ride_id'])
    return df

# dim booking
dp.create_auto_cdc_flow(
    target = 'dim_booking',
    source = 'dim_booking_view',
    keys = ["ride_id"],
    sequence_by = "ride_id",
    stored_as_scd_type = 1
)

dp.create_streaming_table("dim_pickup")


@dp.view
def dim_pickup_view():
    df = spark.readStream.table("silver_obt")
    df = df.select('pickup_city_id',
                   'pickup_location_id',
                   'pickup_address',
                   'pickup_latitude',
                   'pickup_longitude')
                 
   
    df = df.dropDuplicates(subset = ['pickup_city_id'])
    return df

# dim pickup
dp.create_auto_cdc_flow(
    target = 'dim_pickup',
    source = 'dim_pickup_view',
    keys = ["pickup_city_id"],
    sequence_by = "pickup_city_id",
    stored_as_scd_type = 1
)

dp.create_streaming_table("fact_uber")

@dp.view
def fact_uber_view():
    df = spark.readStream.table("silver_obt")
    df = df.select('ride_id',
                   'pickup_city_id',
                   'payment_method_id',
                   'driver_id',
                   'passenger_id',
                   'vehicle_id',
                   'distance_miles',
    'duration_minutes',
    'base_fare',
    'distance_fare',
    'time_fare',
    'surge_multiplier',
    'subtotal',
    'tip_amount',
    'total_fare',
    'rating',
    'base_rate',
    'per_mile',
    'per_minute')
    df = df.dropDuplicates(subset = ['ride_id'])
    return df

# fact uber
dp.create_auto_cdc_flow(
    target = 'fact_uber',
    source = 'fact_uber_view',
    keys = ["ride_id",'pickup_city_id','payment_method_id','driver_id','passenger_id','vehicle_id'],
    sequence_by = "ride_id",
    stored_as_scd_type = 1
    )



