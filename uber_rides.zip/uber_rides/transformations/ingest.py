
from pyspark import pipelines as dp
from pyspark.sql.functions import col
from pyspark.sql.types import StringType

# Event Hubs configuration
# EH_NAMESPACE                    = spark.conf.get("iot.ingestion.eh.namespace")
# EH_NAME                         = spark.conf.get("iot.ingestion.eh.name")
EH_NAMESPACE = "uberEventsStream"
EH_NAME = "uberkafkatopic"


# EH_CONN_SHARED_ACCESS_KEY_NAME  = spark.conf.get("iot.ingestion.eh.accessKeyName")
# SECRET_SCOPE                    = spark.conf.get("io.ingestion.eh.secretsScopeName")
# EH_CONN_SHARED_ACCESS_KEY_VALUE = dbutils.secrets.get(scope = SECRET_SCOPE, key = EH_CONN_SHARED_ACCESS_KEY_NAME)


# EH_CONN_STR                     = f"Endpoint=sb://{EH_NAMESPACE}.servicebus.windows.net/;SharedAccessKeyName={EH_CONN_SHARED_ACCESS_KEY_NAME};SharedAccessKey={EH_CONN_SHARED_ACCESS_KEY_VALUE}"

# EH_CONN_STR = spark.conf.get("connection_string")
# Kafka Consumer configuration
EH_CONN_STR = 'Endpoint=sb://ubereventsstream.servicebus.windows.net/;SharedAccessKeyName=ListenPolicy;SharedAccessKey=aiteD2GFROlPUjBQ4MmG6hZctYSl6amIW+AEhCw4gG0=;EntityPath=uberkafkatopic'

KAFKA_OPTIONS = {
  "kafka.bootstrap.servers"  : f"{EH_NAMESPACE}.servicebus.windows.net:9093",
  "subscribe"                : EH_NAME,
  "kafka.sasl.mechanism"     : "PLAIN",
  "kafka.security.protocol"  : "SASL_SSL",
  "kafka.sasl.jaas.config"   : f"kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username=\"$ConnectionString\" password=\"{EH_CONN_STR}\";",
#   "kafka.request.timeout.ms" : spark.conf.get("iot.ingestion.kafka.requestTimeout"),
#   "kafka.session.timeout.ms" : spark.conf.get("iot.ingestion.kafka.sessionTimeout"),
#   "maxOffsetsPerTrigger"     : spark.conf.get("iot.ingestion.spark.maxOffsetsPerTrigger"),
#   "failOnDataLoss"           : spark.conf.get("iot.ingestion.spark.failOnDataLoss"),
#   "startingOffsets"          : spark.conf.get("iot.ingestion.spark.startingOffsets")
    "kafka.request.timeout.ms" : 10000,
  "kafka.session.timeout.ms" : 100000,
  "maxOffsetsPerTrigger"     : 10000,
  "failOnDataLoss"           : "true",
  "startingOffsets"          : "earliest"
}

@dp.table
def rides_rawdata():
    df = spark.readStream.format("kafka")\
        .options(**KAFKA_OPTIONS)\
        .load()

    # vonverting values to string
    df = df.withColumn("rides",col("value").cast(StringType()))
    return df

